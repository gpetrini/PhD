REPLICATION FILES
Estimating Keynesian models of business fluctuations using Bayesian Maximum Likelihood
Christian Schoder
ROKE 2017


Schoder 2017 ROKE         The pdf of the paper.
model_pk.mod              The file to be executed by dynare in matlab to estimate the PK model.
model_pk_steadystate      The external steady state file which model_pk.mod refers to to obtain the steady state after each parameter draw.
data_ea.mat               The data file. 

# TODO

- [ ] Explicitar hipótese de trabalho
- [ ] Escrever um resumo mais direto
- [ ] Detalhar melhor QCA
- [ ] Explicar como a lógica fuzzy será utilizada

	- A depender de conversas (Rosângela/Aggio)
- [ ] Incluir co-orientador
- [ ] Explicitar universidades para sanduíche
- [ ] Incluir referência para sobol
- [ ] Seção sobre análise de resultados